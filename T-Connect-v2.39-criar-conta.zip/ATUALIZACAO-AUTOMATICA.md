# Atualização automática via GitHub (passo a passo)

Depois de configurado, o seu trabalho para lançar uma nova versão é só **criar uma tag**.
O GitHub compila, assina e publica os dois APKs, e o app instalado deteta e baixa a nova versão sozinho.

> Lembrete honesto: no Android, fora da Play Store, aparece sempre **um** ecrã final "Atualizar?" onde a pessoa toca uma vez. Não há como evitar isso sem a Play Store. Tudo o resto é automático.

---

## Parte 1 — Criar a chave de assinatura (uma única vez)

A chave tem de ser **sempre a mesma** em todas as versões, senão o Android recusa a atualização.

No seu PC, dentro de `android-native/`:

```powershell
keytool -genkey -v -keystore tconnect.keystore -alias tconnect -keyalg RSA -keysize 2048 -validity 10000
```

Responda às perguntas e **guarde bem a senha**. Guarde também o ficheiro `tconnect.keystore` num sítio seguro (com backup). Se o perder, nunca mais consegue atualizar o app — só reinstalar do zero.

> O `tconnect.keystore` **não** deve ir para o GitHub em texto. Vai como segredo (Parte 3).

---

## Parte 2 — Pôr o projeto no GitHub

1. Crie um repositório novo (pode ser **privado**) em https://github.com/new
2. Envie a pasta do projeto para lá. Pelo VS Code: **Source Control** (ícone dos ramos) → *Publish to GitHub*. Ou por linha de comando, dentro da pasta do projeto:

```powershell
git init
git add .
git commit -m "T-Connect inicial"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/SEU_REPO.git
git push -u origin main
```

> Não envie o `tconnect.keystore` nem o `keystore.properties`. Crie um ficheiro `.gitignore` com estas duas linhas:
> ```
> tconnect.keystore
> keystore.properties
> ```

---

## Parte 3 — Guardar os segredos no GitHub

No repositório: **Settings → Secrets and variables → Actions → New repository secret**. Crie 4 segredos:

| Nome | Valor |
|---|---|
| `KEYSTORE_BASE64` | o `tconnect.keystore` convertido em texto base64 (comando abaixo) |
| `KEYSTORE_PASSWORD` | a senha da keystore |
| `KEY_ALIAS` | `tconnect` |
| `KEY_PASSWORD` | a senha da chave (normalmente a mesma da keystore) |

Para obter o `KEYSTORE_BASE64`, corra no PowerShell dentro de `android-native/`:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("tconnect.keystore")) | Set-Clipboard
```

Isto copia o texto para a área de transferência — cole-o no valor do segredo `KEYSTORE_BASE64`.

---

## Parte 4 — Lançar uma versão

Sempre que quiser publicar uma nova versão:

```powershell
git tag v2.39.6
git push origin v2.39.6
```

(troque `2.39.6` pela versão que quiser; use sempre números crescentes)

O GitHub vai, sozinho:
1. compilar os dois APKs **assinados** com a sua chave,
2. criar um *Release* com `app-child-release.apk` e `app-guardian-release.apk`,
3. atualizar o `updates/t-connect-update.json` com a nova versão.

Pode acompanhar em **Actions** no seu repositório. Demora ~5–10 min.

---

## Parte 5 — Como o app se atualiza

- **Guardian**: já tem "Atualização automática" nas Definições. Ao abrir, verifica o manifesto remoto; se houver versão nova, baixa e abre o instalador (um toque em "Atualizar").
- **Child (Minha Emergência)**: no menu, a opção "Minha Emergência → Instalar/atualizar" baixa a versão mais recente do APK Child.

Os links já apontam para `releases/latest/download/...`, por isso **nunca mudam** — apontam sempre para a versão mais recente.

---

## IMPORTANTE — primeira instalação nos telemóveis reais

O APK **debug** que você gerou no PC (para teste) está assinado com uma chave diferente da de produção. Por isso:

1. Nos telemóveis que vão usar o app a sério, **desinstale** qualquer versão debug antes.
2. Instale o APK **de produção** (o do GitHub Releases) desde o início.
3. A partir daí, todas as próximas versões (também do GitHub) atualizam por cima, sem perder dados.

Se tentar atualizar um app debug com um release (ou vice-versa), o Android recusa por "conflito de assinatura".

---

## Resumo do fluxo diário

1. Muda o código → `git commit` → `git push`
2. `git tag vX.Y.Z` → `git push origin vX.Y.Z`
3. Espera o GitHub Actions terminar
4. Os apps instalados atualizam-se sozinhos (com um toque em "Atualizar")
