# v2.38.40 — Áudio exclusivo da Criança

Adicionada uma função no Guardian para solicitar somente o microfone da Criança, sem câmera. O Child precisa aceitar explicitamente e o Android/browser precisa conceder a permissão do microfone. A transmissão usa WebRTC e o Guardian mostra um painel de áudio ao vivo.
