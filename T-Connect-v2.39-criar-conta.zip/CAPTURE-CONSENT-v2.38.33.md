# v2.38.33 — Consentimento para captura

- Guardian: o botão de captura cria um pedido PENDENTE para o dispositivo Child.
- Child: recebe uma mensagem explícita para Aceitar ou Recusar.
- Nenhum acesso de captura é iniciado antes da aceitação.
- Após aceitar, o Child solicita a captura oficial de tela do navegador/Android e negocia o vídeo com o Guardian via WebRTC.
- Recusar mantém a captura bloqueada.
- Encerrar no Guardian encerra a sessão no Child.
- A captura continua sujeita às permissões e aos diálogos oficiais do sistema.
