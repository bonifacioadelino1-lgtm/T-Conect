# v2.38.47 — Controles compactos do mapa

Mapa, Satélite e Híbrido ficam juntos em um único grupo compacto, sempre visível, com ícones e tooltips. O Atualizar do mapa permanece removido; a atualização geral fica no topo do Monitoramento.
