# T-Connect v2.38.43 — mapa reativado

Corrige a regressão que impedia o Leaflet de abrir: a restauração da última localização era chamada antes de o marcador/círculo serem criados.

Também protege a grade de coordenadas contra erros e limita o número de linhas durante zoom.
