# T-Connect v2.38.44 — Mapa reativado e marcador robusto

Correção do erro `Cannot read properties of null (reading 'setLatLng')`.

- O mapa só troca as camadas depois de criar marcador e círculo de precisão.
- `restoreLastKnownLocation()` recria objetos Leaflet ausentes quando necessário.
- `setLocation()` também recria marcador/círculo se o Guardian tiver re-renderizado o mapa.
- Mapa, Satélite e Híbrido preservam a última localização conhecida.
- O marcador permanece acima das camadas.
- Atualização de cache do módulo do mapa para v2.38.44.
