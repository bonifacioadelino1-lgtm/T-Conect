# T-Connect v2.39.2 — Monitoramento + Mapa

## Alterações
- O botão **Atualizar** agora pertence exclusivamente ao cabeçalho de **Monitoramento (Visão geral)**.
- O botão não aparece nas telas secundárias/mapa.
- Atualização sem `location.reload()`: sincroniza dispositivos/eventos e preserva a sessão e o estado visual.
- Botão com estado visual `Atualizando…`, bloqueio contra cliques duplicados e animação profissional.
- Mapa/Satélite/Híbrido trocam a camada diretamente, sem reconstruir o dashboard inteiro.
- Os botões de camada recebem estado `aria-pressed` e destaque imediato.
- A troca de camada preserva ponteiro, última localização e coordenadas.
- O `MutationObserver` do mapa foi debounced para evitar inicializações repetidas durante renders.
- Após troca de camada, o Leaflet recebe `invalidateSize()` para estabilizar o desenho.

## Teste recomendado
1. Abrir Guardian e entrar em Monitoramento.
2. Confirmar que **Atualizar** está no canto superior direito.
3. Clicar Atualizar uma vez e observar `Atualizando…` → `Atualizar`.
4. No mapa, clicar Mapa, Satélite e Híbrido repetidamente.
5. Confirmar que o botão selecionado fica destacado imediatamente.
6. Confirmar que o ponteiro permanece visível em todos os modos.
7. Fazer zoom e arrastar o mapa; confirmar que o ponteiro e coordenadas permanecem.
8. Entrar em Localização e confirmar que não existe botão Atualizar dentro do mapa.
