# T-Connect v2.38.46 — Atualização do Monitoramento

- O botão Atualizar foi movido para o cabeçalho superior do Guardian.
- A atualização recarrega os dados do monitoramento, incluindo o mapa.
- O botão Atualizar dentro dos controles do mapa foi removido.
- A última camada do mapa é preservada.
- O mapa é redimensionado/revalidado após a atualização.
