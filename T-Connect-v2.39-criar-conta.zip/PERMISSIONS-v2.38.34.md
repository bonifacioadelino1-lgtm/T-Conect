# v2.38.34 — Permissões reais

- Android: solicita câmera, microfone, localização, notificações, SMS e chamadas através das APIs oficiais.
- WebView: câmera/microfone só são concedidos ao conteúdo web quando a permissão Android correspondente já foi concedida.
- Captura de tela: usa MediaProjection e sempre apresenta a confirmação oficial do Android.
- Nenhuma permissão é concedida silenciosamente; o Android controla a autorização do utilizador.
