# T-Connect v2.39.1 — teste de estabilização

## Child / Minha Segurança
- Inicialização sem login.
- QR, código e link mantidos.
- Estado de permissões protegido contra localStorage corrompido.
- Uma falha de permissão não deve impedir a abertura do Child.

## Guardian / Mapa
- Mapa abre independentemente de existir localização atual.
- Última localização permanece visível quando disponível.
- Ponteiro permanece em Mapa, Satélite e Híbrido.
- Coordenadas exatas continuam visíveis no HUD.
- Linhas de grade e trilha visual foram removidas.
- Zoom/fly-to mantém o ponteiro.
- Falha do módulo do mapa mostra uma mensagem de recuperação em vez de deixar a tela vazia.

## Nota
Os mapas e geocodificação usam serviços externos; o dispositivo precisa de acesso à internet para tiles e nomes de área.
