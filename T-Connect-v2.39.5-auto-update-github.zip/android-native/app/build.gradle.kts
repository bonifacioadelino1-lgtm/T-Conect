import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Versão: pode vir por -PappVersionName / -PappVersionCode (usado pelo CI).
val appVersionName = (findProperty("appVersionName") as String?) ?: "2.39.5"
val appVersionCode = (findProperty("appVersionCode") as String?)?.toIntOrNull() ?: 2398

// Assinatura: lê de keystore.properties (local) OU de variáveis de ambiente (CI).
val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
fun signCfg(propKey: String, envKey: String): String? =
    keystoreProps.getProperty(propKey) ?: System.getenv(envKey)
val storeFilePath = signCfg("storeFile", "KEYSTORE_FILE")

android {
    namespace = "com.tconnect.child"
    compileSdk = 35

    defaultConfig {
        minSdk = 26
        targetSdk = 35
        versionCode = appVersionCode
        versionName = appVersionName
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        buildConfig = true
    }

    signingConfigs {
        create("release") {
            if (storeFilePath != null) {
                storeFile = file(storeFilePath)
                storePassword = signCfg("storePassword", "KEYSTORE_PASSWORD")
                keyAlias = signCfg("keyAlias", "KEY_ALIAS")
                keyPassword = signCfg("keyPassword", "KEY_PASSWORD")
            }
        }
    }

    flavorDimensions += "app"
    productFlavors {
        create("child") {
            dimension = "app"
            applicationId = "com.tconnect.child"
            buildConfigField(
                "String",
                "START_URL",
                "\"https://appassets.androidplatform.net/assets/tc236/child/index.html\""
            )
        }
        create("guardian") {
            dimension = "app"
            applicationId = "com.tconnect.guardian"
            buildConfigField(
                "String",
                "START_URL",
                "\"https://appassets.androidplatform.net/assets/tc236/guardian/index.html\""
            )
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            if (storeFilePath != null) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
